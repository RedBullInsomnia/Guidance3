
heading_controller.Ki = 0.06;
heading_controller.Kp = 2000;
heading_controller.Kd = 100;

heading_controller.lf4 = -1.8257e+06;
heading_controller.lf1 = 500;
heading_controller.lf2 = -20;

save('heading_controller', 'heading_controller');
