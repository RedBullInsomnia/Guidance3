
surge_controller.Ki = -0.01;
surge_controller.Kp = -300;

save('surge_controller', 'surge_controller');