function output = radtodeg(input)

output = input * (180 / pi);

end

